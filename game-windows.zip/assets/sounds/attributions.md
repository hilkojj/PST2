### Sound effects used in the game

Click the (file)name to go to the original download page.
<!---
- [`example.ogg`](https://freesound.org/example) **by** example [(CC BY 3.0)](https://creativecommons.org/licenses/by/3.0/) (adapted)
-->

