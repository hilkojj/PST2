
function create(model)
    applyTemplate(model, "TileShape", { modelName = "TileSlope" })
end
